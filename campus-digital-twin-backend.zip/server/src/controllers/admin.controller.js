const db = require('../config/db');

// GET /api/admin/stats
async function getStats(req, res, next) {
  try {
    const total = db.prepare('SELECT COUNT(*) AS count FROM complaints').get().count;

    const byStatus = db
      .prepare('SELECT status, COUNT(*) AS count FROM complaints GROUP BY status')
      .all();

    const byCategory = db
      .prepare('SELECT category, COUNT(*) AS count FROM complaints GROUP BY category ORDER BY count DESC')
      .all();

    const byPriority = db
      .prepare('SELECT priority, COUNT(*) AS count FROM complaints GROUP BY priority')
      .all();

    const byBuilding = db
      .prepare(
        `SELECT building, COUNT(*) AS count FROM complaints
         WHERE building IS NOT NULL
         GROUP BY building ORDER BY count DESC LIMIT 10`
      )
      .all();

    const highPriorityOpen = db
      .prepare(`SELECT COUNT(*) AS count FROM complaints WHERE priority = 'High' AND status != 'Resolved'`)
      .get().count;

    res.json({
      success: true,
      stats: {
        total,
        highPriorityOpen,
        byStatus,
        byCategory,
        byPriority,
        mostAffectedBuildings: byBuilding,
      },
    });
  } catch (err) {
    next(err);
  }
}

module.exports = { getStats };
