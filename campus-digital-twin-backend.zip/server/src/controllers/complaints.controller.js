const db = require('../config/db');
const { AppError } = require('../middleware/errorHandler');

// POST /api/complaints  (student)
// Note: category/priority are plain fields here, not AI-classified. Member 4's
// AI module owns classification and can update these fields later via
// PATCH /api/complaints/:id/classification (see updateClassification below).
async function createComplaint(req, res, next) {
  try {
    const { title, description, building, room } = req.body;
    const category = req.body.category || 'Uncategorized';
    const priority = ['Low', 'Medium', 'High'].includes(req.body.priority) ? req.body.priority : 'Medium';
    const photoPath = req.file ? `/uploads/${req.file.filename}` : null;

    const result = db
      .prepare(
        `INSERT INTO complaints (user_id, title, description, building, room, category, priority, photo_path)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(req.user.id, title, description, building || null, room || null, category, priority, photoPath);

    const complaint = db.prepare('SELECT * FROM complaints WHERE id = ?').get(result.lastInsertRowid);

    res.status(201).json({ success: true, complaint });
  } catch (err) {
    next(err);
  }
}

// GET /api/complaints  (student: own complaints, admin: all, with filters)
async function listComplaints(req, res, next) {
  try {
    const { status, category, building } = req.query;
    const isAdmin = req.user.role === 'admin';

    const conditions = [];
    const params = [];

    if (!isAdmin) {
      conditions.push('user_id = ?');
      params.push(req.user.id);
    }
    if (status) {
      conditions.push('status = ?');
      params.push(status);
    }
    if (category) {
      conditions.push('category = ?');
      params.push(category);
    }
    if (building) {
      conditions.push('building = ?');
      params.push(building);
    }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const complaints = db
      .prepare(`SELECT * FROM complaints ${where} ORDER BY created_at DESC`)
      .all(...params);

    res.json({ success: true, count: complaints.length, complaints });
  } catch (err) {
    next(err);
  }
}

// GET /api/complaints/:id
async function getComplaint(req, res, next) {
  try {
    const complaint = db.prepare('SELECT * FROM complaints WHERE id = ?').get(req.params.id);

    if (!complaint) return next(new AppError('Complaint not found', 404));

    const isOwner = complaint.user_id === req.user.id;
    if (req.user.role !== 'admin' && !isOwner) {
      return next(new AppError('You do not have permission to view this complaint', 403));
    }

    res.json({ success: true, complaint });
  } catch (err) {
    next(err);
  }
}

// PATCH /api/complaints/:id/status  (admin only)
async function updateStatus(req, res, next) {
  try {
    const { status } = req.body;
    const complaint = db.prepare('SELECT * FROM complaints WHERE id = ?').get(req.params.id);

    if (!complaint) return next(new AppError('Complaint not found', 404));

    db.prepare(`UPDATE complaints SET status = ?, updated_at = datetime('now') WHERE id = ?`).run(
      status,
      req.params.id
    );

    const updated = db.prepare('SELECT * FROM complaints WHERE id = ?').get(req.params.id);
    res.json({ success: true, complaint: updated });
  } catch (err) {
    next(err);
  }
}

// PATCH /api/complaints/:id/classification  (admin only for now)
// Hook for Member 4's AI module to set category/priority once it classifies
// a complaint. Kept separate from updateStatus so the two concerns don't mix.
async function updateClassification(req, res, next) {
  try {
    const { category, priority } = req.body;
    const complaint = db.prepare('SELECT * FROM complaints WHERE id = ?').get(req.params.id);

    if (!complaint) return next(new AppError('Complaint not found', 404));

    db.prepare(
      `UPDATE complaints SET category = COALESCE(?, category), priority = COALESCE(?, priority), updated_at = datetime('now') WHERE id = ?`
    ).run(category || null, priority || null, req.params.id);

    const updated = db.prepare('SELECT * FROM complaints WHERE id = ?').get(req.params.id);
    res.json({ success: true, complaint: updated });
  } catch (err) {
    next(err);
  }
}

// DELETE /api/complaints/:id  (owner or admin)
async function deleteComplaint(req, res, next) {
  try {
    const complaint = db.prepare('SELECT * FROM complaints WHERE id = ?').get(req.params.id);
    if (!complaint) return next(new AppError('Complaint not found', 404));

    const isOwner = complaint.user_id === req.user.id;
    if (req.user.role !== 'admin' && !isOwner) {
      return next(new AppError('You do not have permission to delete this complaint', 403));
    }

    db.prepare('DELETE FROM complaints WHERE id = ?').run(req.params.id);
    res.json({ success: true, message: 'Complaint deleted' });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  createComplaint,
  listComplaints,
  getComplaint,
  updateStatus,
  updateClassification,
  deleteComplaint,
};
