const express = require('express');
const { authenticate, requireRole } = require('../middleware/auth');
const { getStats } = require('../controllers/admin.controller');

const router = express.Router();

router.use(authenticate, requireRole('admin'));

router.get('/stats', getStats);

module.exports = router;
