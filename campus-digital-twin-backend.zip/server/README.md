# Campus Digital Twin — Backend (Member 2 scope)

Backend for **Campus Digital Twin + AI Maintenance Assistant**, covering only
the Member 2 responsibilities: login system, complaint storage, photo uploads,
REST APIs for the frontend, and complaint status updates.

Tested against **Node v24.16.0 / npm 11.13.0**.

## Tech stack
- Node.js + Express
- SQLite via Node's **built-in** `node:sqlite` module — zero-config, file-based, and needs **no native compilation** (no Visual Studio Build Tools, no node-gyp). Requires Node >= 22.5; you're on v24.16.0 so you're covered.
- JWT auth (`jsonwebtoken`) with `student` / `admin` roles
- `bcryptjs` for password hashing
- `multer` for complaint photo uploads
- `helmet`, `express-rate-limit`, `express-validator` for security/validation
- `jest` + `supertest` for the integration test suite

You'll see a one-line `ExperimentalWarning: SQLite is an experimental feature`
in the console on startup — that's expected and harmless, it's just Node
telling you the built-in module is newer than the rest of its API.

## Setup

```bash
cd server
npm install
```

Then create your `.env` file (PowerShell doesn't have Unix `cp` by default the way you tried it — use one of these instead):

```powershell
copy .env.example .env
```
or, if you have Git Bash / WSL:
```bash
cp .env.example .env
```

Edit `.env` and set a real `JWT_SECRET`, and `CORS_ORIGIN` to your frontend URL. Then:

```bash
npm start        # production — runs src/server.js
npm run dev      # auto-restart on changes
```

Note: the entry file is `src/server.js`, not `server.js` at the root — so use `npm start`, not `node server.js`.

Server runs on `http://localhost:5000` by default (`PORT` in `.env`).

## Running tests

```bash
npm test
```

18 integration tests cover auth, complaint CRUD, role-based access, and admin stats.

## Folder structure

```
server/
  src/
    app.js               Express app: middleware + route mounting
    server.js             Entry point
    config/db.js          SQLite connection + schema/indexes
    middleware/           auth (JWT), upload (multer), validate, errorHandler
    controllers/          auth, complaints, admin
    routes/                auth, complaints, admin
    utils/aiClassifier.js  AI classification hook (Member 4 can swap internals)
  tests/                  Jest + supertest integration tests
  uploads/                Uploaded complaint photos (served at /uploads/<file>)
```

## API reference

All responses are JSON: `{ success: boolean, ...data }` or `{ success: false, message }`.

### Auth — `/api/auth`
| Method | Path | Auth | Body | Notes |
|---|---|---|---|---|
| POST | `/register` | — | `name, email, password, role?` | `role` defaults to `student` |
| POST | `/login` | — | `email, password` | Returns `{ token, user }` |
| GET | `/me` | Bearer token | — | Returns current user |

### Complaints — `/api/complaints` (all require `Authorization: Bearer <token>`)
| Method | Path | Role | Body / Query | Notes |
|---|---|---|---|---|
| POST | `/` | student/admin | `multipart/form-data`: `title, description, building?, room?, photo?, category?, priority?` | `category` defaults to `Uncategorized`, `priority` to `Medium` if not sent — no AI involved here, that's Member 4's module |
| GET | `/` | student/admin | Query: `status?, category?, building?` | Students see only their own complaints; admins see all |
| GET | `/:id` | owner/admin | — | 404 if not found, 403 if not owner/admin |
| PATCH | `/:id/status` | admin only | `{ status }` (`Open`, `In Progress`, `Resolved`, `Rejected`) | |
| PATCH | `/:id/classification` | admin only | `{ category?, priority? }` | Hook for Member 4's AI module to set/update classification after the fact |
| DELETE | `/:id` | owner/admin | — | |

### Admin — `/api/admin` (admin only)
| Method | Path | Notes |
|---|---|---|
| GET | `/stats` | Totals, breakdown by status/category/priority, top affected buildings, high-priority-open count |

### Health check
`GET /api/health` → `{ success: true, message: "Backend is running" }`

## AI classification (out of scope here — this is Member 4's module)

This backend does **not** call any AI API. Complaints are stored with
whatever `category`/`priority` the frontend sends (defaulting to
`Uncategorized` / `Medium` if omitted). Once Member 4's AI module classifies
a complaint, it can update those fields with:

```
PATCH /api/complaints/:id/classification
Authorization: Bearer <admin token>
{ "category": "Plumbing", "priority": "High" }
```

That's the only integration point needed between the two modules.

## Connecting to the frontend

Set `CORS_ORIGIN` in `.env` to your deployed frontend URL, e.g.:
```
CORS_ORIGIN=https://campus-digital-twin-ai-2-new.vercel.app
```
Multiple origins can be comma-separated.

If the frontend's expected request/response shapes differ from what's above
(e.g. different field names), share the frontend's API calls and the
controllers/routes can be adjusted to match exactly — this backend was built
from the shared project spec and is not connected to the actual frontend
code yet.
