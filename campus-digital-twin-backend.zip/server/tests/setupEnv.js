process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = 'test_secret_key';
process.env.JWT_EXPIRES_IN = '1h';
process.env.DB_PATH = './data/test.db';
process.env.UPLOAD_DIR = './uploads_test';
process.env.CORS_ORIGIN = '*';
