const request = require('supertest');
const fs = require('fs');
const path = require('path');

const dbFile = path.resolve(process.env.DB_PATH || './data/test.db');
if (fs.existsSync(dbFile)) fs.unlinkSync(dbFile);

const app = require('../src/app');

describe('Auth API', () => {
  const user = {
    name: 'Test Student',
    email: 'student1@test.com',
    password: 'password123',
  };

  it('registers a new user', async () => {
    const res = await request(app).post('/api/auth/register').send(user);
    expect(res.status).toBe(201);
    expect(res.body.success).toBe(true);
    expect(res.body.token).toBeDefined();
    expect(res.body.user.email).toBe(user.email);
    expect(res.body.user.role).toBe('student');
  });

  it('rejects duplicate registration', async () => {
    const res = await request(app).post('/api/auth/register').send(user);
    expect(res.status).toBe(409);
  });

  it('rejects invalid registration payload', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .send({ name: '', email: 'bad-email', password: '123' });
    expect(res.status).toBe(422);
  });

  it('logs in with correct credentials', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({ email: user.email, password: user.password });
    expect(res.status).toBe(200);
    expect(res.body.token).toBeDefined();
  });

  it('rejects login with wrong password', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({ email: user.email, password: 'wrongpassword' });
    expect(res.status).toBe(401);
  });

  it('returns current user profile with a valid token', async () => {
    const loginRes = await request(app)
      .post('/api/auth/login')
      .send({ email: user.email, password: user.password });

    const res = await request(app)
      .get('/api/auth/me')
      .set('Authorization', `Bearer ${loginRes.body.token}`);

    expect(res.status).toBe(200);
    expect(res.body.user.email).toBe(user.email);
  });

  it('rejects /me without a token', async () => {
    const res = await request(app).get('/api/auth/me');
    expect(res.status).toBe(401);
  });
});
