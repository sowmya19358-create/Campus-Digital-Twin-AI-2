const request = require('supertest');
const app = require('../src/app');

describe('Admin API', () => {
  let studentToken;
  let adminToken;

  beforeAll(async () => {
    const student = await request(app).post('/api/auth/register').send({
      name: 'Stats Student',
      email: 'stats.student@test.com',
      password: 'password123',
    });
    studentToken = student.body.token;

    const admin = await request(app).post('/api/auth/register').send({
      name: 'Stats Admin',
      email: 'stats.admin@test.com',
      password: 'password123',
      role: 'admin',
    });
    adminToken = admin.body.token;

    await request(app)
      .post('/api/complaints')
      .set('Authorization', `Bearer ${studentToken}`)
      .send({
        title: 'Broken chair in Room 101',
        description: 'The chair in Room 101 is broken',
        building: 'Building B',
        room: '101',
      });
  });

  it('blocks students from viewing stats', async () => {
    const res = await request(app)
      .get('/api/admin/stats')
      .set('Authorization', `Bearer ${studentToken}`);
    expect(res.status).toBe(403);
  });

  it('lets admins view aggregated stats', async () => {
    const res = await request(app)
      .get('/api/admin/stats')
      .set('Authorization', `Bearer ${adminToken}`);

    expect(res.status).toBe(200);
    expect(res.body.stats.total).toBeGreaterThanOrEqual(1);
    expect(Array.isArray(res.body.stats.byCategory)).toBe(true);
    expect(Array.isArray(res.body.stats.mostAffectedBuildings)).toBe(true);
  });
});
